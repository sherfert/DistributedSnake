Drop the umundoNativeJava[_d].so library from the installation directory for
android here.
