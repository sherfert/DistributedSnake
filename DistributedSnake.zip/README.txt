 In order to compile the app and install it on your phone, execute the following steps in your command line (protobuf and ant have to be installed):
 
 //cd appcompat_v7
 //ant clean
 //cd ../test01
 cd test01
 ant gen_instrument_install
 
 This will instaill the app (DistributedSnake) on your phone, but not run it automatically.
 
 If you want to use eclipse, you can also import the two projects (appcompat_v7 is a dependecy). Eclipse will show compilation errors (missing protobuf generated files), that can be solved by running 'ant gen' in the 'test01' folder.